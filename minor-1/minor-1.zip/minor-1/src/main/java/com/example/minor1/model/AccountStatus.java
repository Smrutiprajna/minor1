package com.example.minor1.model;

public enum AccountStatus {

    ACTIVE,
    INACTIVE,
    BLOCKED,
    PAUSED
}
