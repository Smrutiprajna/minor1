package com.example.minor1.controller;

public class TransactionController {
}
