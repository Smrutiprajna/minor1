package com.example.minor1.service;

public class StudentService {
}
