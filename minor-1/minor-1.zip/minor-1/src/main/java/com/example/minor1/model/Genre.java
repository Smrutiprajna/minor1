package com.example.minor1.model;

public enum Genre {

    FICTIONAL,
    NON_FICTIONAL,
    SCIENCE_AND_TECHNOLOGY,
    HISTORY,
    PSYCHOLOGY,
    COMICS
}
